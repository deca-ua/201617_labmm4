<?php include_once "navigation.php"; ?>

<style type="text/css">@import url("content/style.css"); </style>

<div id="main" class="centra">
    <div id="game" class="bemvindo">
        <div id="info" class="balao">Estou a pensar num número entre 1 e 1000!</div>
        <div id="msg" class="quadro" style="color: white;">Bem-vindo ao Jogo do número secreto (10 Tentativas)</div>
        <div class="iform">
            <form action="jogo.php" method="post">
                <label for="number" style="color: white;">Adivinha o número</label><br>
                <input type="text" id="number" name="msg" size="4" maxlength="4" autofocus>
                <input type="submit" value="Enviar">
            </form>
        </div>
    </div>
</div>





