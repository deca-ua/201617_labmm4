<?php
$mentor1_id="5";
$mentor1_name="Joana Beja";
$mentor1_title="especial mentor";
$mentor1_description_short="ex-NTC e atualmente a terminar o Mestrado em Design, a Joana não esconde que o seu piso preferido do CCCI é o do meio.";
$mentor1_description="ex-NTC e atualmente a terminar o Mestrado em Design, a Joana não esconde que o seu piso preferido do CCCI é o do meio.<br>Se por um lado a comunicação lhe está no sangue, por outro é a programação que a desafia, e junta-se à AVILA Crew para ajudar na luta contra o insucesso de Lab4.";
$mentor1_image="specialmentor_JOANA.png";
$mentor1_user="joana";
$mentor1_pass="beja";

$mentor2_id="6";
$mentor2_name="Guilherme Cabral";
$mentor2_title="especial mentor";
$mentor2_description_short="Apesar de cobiçado por colossos da tecnologia mundial, o Guilherme é atualmente sysadmin e backend developer no SAPO Campus.";
$mentor2_description="Apesar de cobiçado por colossos da tecnologia mundial, o Guilherme é atualmente sysadmin e backend developer no SAPO Campus.<br>Ex-NTC e ex-MCMM, faz parte da AVILA Crew, sendo uma das pessoas que te pode ajudar a conhecer tecnologias e ferramentas para além do que é lecionado em Lab4.";
$mentor2_image="specialmentor_GUI.png";
$mentor2_user="guilherme";
$mentor2_pass="cabral";


$mentor3_id="7";
$mentor3_name="Rita Lopes";
$mentor3_title="especial mentor";
$mentor3_description_short="No último ano da licenciatura em NTC, a Rita assume preferência pelo mundo da programação. A título de curiosidade, é o desenvolvimento de jogos que mais a desafia apesar de assumir o seu péssimo jeito para os jogar!";
$mentor3_description="No último ano da licenciatura em NTC, a Rita assume preferência pelo mundo da programação. A título de curiosidade, é o desenvolvimento de jogos que mais a desafia apesar de assumir o seu péssimo jeito para os jogar!<br>Junta-se à AVILA Crew para partilhar este gosto e demonstrar que Lab4 pode ser uma UC bem simpática.";
$mentor3_image="specialmentor_RITA.png";
$mentor3_user="rita";
$mentor3_pass="lopes";