<div class="row">
    <div class="col-lg-12 col-sm-6 text-center">
        ups!!!!
    </div>
</div>