<div class="row">
    <div class="col-lg-12">
        <h2 class="page-header">Disponível Brevemente</h2>
        <img src="images/commingsoon.jpg" class="img-responsive center"> </img>
    </div>

</div>