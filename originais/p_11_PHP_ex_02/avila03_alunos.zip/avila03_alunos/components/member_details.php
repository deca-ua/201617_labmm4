<?php require_once "data/team_members_data.php";
$error = false;
if (isset($_GET["id"])) {
    switch ($_GET["id"]) {
        case 5:
            $mentor_image = $mentor1_image;
            $mentor_name = $mentor1_name;
            $mentor_title = $mentor1_title;
            $mentor_description = $mentor1_description;
            break;
        case 6:
            $mentor_image = $mentor2_image;
            $mentor_name = $mentor2_name;
            $mentor_title = $mentor2_title;
            $mentor_description = $mentor2_description;
            break;
        case 7:
            $mentor_image = $mentor3_image;
            $mentor_name = $mentor3_name;
            $mentor_title = $mentor3_title;
            $mentor_description = $mentor3_description;
            break;
        default:
            $error = true;
    }
} else {
    $error = true;
}


if ($error) {
    require_once "components/404.php";
} else {

    ?>
    <div class="row">
        <div class="col-lg-12 col-sm-6 text-center">
            <img class="img-circle img-responsive img-center" src="images/<?= $mentor_image; ?>" alt="">
            <h3><?= $mentor_name; ?>
                <small><?= $mentor_title; ?></small>
            </h3>
            <p><?= $mentor_description; ?></p>
        </div>
    </div>
    <?php
}

