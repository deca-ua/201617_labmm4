<?php require_once "data/team_members_data.php"; ?>

<div class="row">
    <div class="col-lg-12">
        <h2 class="page-header">A nossa equipa</h2>
    </div>
    <div class="col-lg-4 col-sm-6 text-center">
        <a href="member_info.php?id=<?= $mentor1_id; ?>"><img class="img-circle img-responsive img-center"
                                               src="images/<?= $mentor1_image; ?>" alt=""></a>
        <h3><?= $mentor1_name; ?>
            <small><?= $mentor1_title; ?></small>
        </h3>
        <p><?= $mentor1_description_short; ?></p>
    </div>
    <div class="col-lg-4 col-sm-6 text-center">

        <a href="member_info.php?id=<?= $mentor2_id; ?>"><img class="img-circle img-responsive img-center"
                                               src="images/<?= $mentor2_image; ?>" alt=""></a>
        <h3><?= $mentor2_name; ?>
            <small><?= $mentor2_title; ?></small>
        </h3>
        <p><?= $mentor2_description_short; ?></p>
    </div>
    <div class="col-lg-4 col-sm-6 text-center">

        <a href="member_info.php?id=<?= $mentor3_id; ?>"> <img class="img-circle img-responsive img-center"
                                                src="images/<?= $mentor3_image; ?>" alt=""></a>
        <h3><?= $mentor3_name; ?>
            <small><?= $mentor3_title; ?></small>
        </h3>
        <p><?= $mentor3_description_short; ?></p>
    </div>

</div>