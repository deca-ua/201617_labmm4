<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Sobre nós
            <small>Conta connosco!</small>
        </h1>
        <p>
            A AVILA Crew é constituída por um conjunto de mentores (voluntários) que tem como missão ser um grupo
            de Apoio à VItima de LAboratório. Foi constituída na UC de Laboratório Multimédia 4, no ano lectivo de
            2016-2017.
        </p>
    </div>
</div>